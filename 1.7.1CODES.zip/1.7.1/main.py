import pygame
import settings
from car import Car
from road import Road
from enemy import Enemy
import os



pygame.init()

su_anki_ekran = "ana_menu"

score = 0
score_font = pygame.font.SysFont("Consolas", 24, bold=True)
genislik_yukseklik = (settings.WIDTH, settings.HEIGHT)
clock = pygame.time.Clock()
durum = True
pencere = pygame.display.set_mode((settings.WIDTH, settings.HEIGHT))
fullscreen = False
font = pygame.font.SysFont(None,60)




button_w=250
button_h=70

oyna_butonu = pygame.Rect(
settings.WIDTH//2 - button_w//2,
settings.HEIGHT//2 - button_h//2,
button_w,
button_h
)

road = Road()
car = Car()
enemies = []
spawn_timer = 0

restart_buton = pygame.Rect(
settings.WIDTH//2-150,
420,
300,
80
)



while durum:
    clock.tick(settings.FPS)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            durum = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            fare_konumu = event.pos
            if oyna_butonu.collidepoint(fare_konumu):
                su_anki_ekran = "oyun"

            if su_anki_ekran=="game_over":
                if restart_buton.collidepoint(event.pos):
                    car=Car()
                    enemies=[]
                    spawn_timer=0
                    su_anki_ekran="oyun"
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_F11:
                fullscreen = not fullscreen

                if fullscreen:
                    pencere = pygame.display.set_mode(
                        (1280,720),
                        pygame.FULLSCREEN
            )
                else:
                    pencere = pygame.display.set_mode(
                    (1280,720)
            )
    

    if su_anki_ekran == "ana_menu":
        pencere.fill((0, 0, 0))
        pygame.draw.rect(pencere, (255, 255, 255), oyna_butonu, 2)
        text = font.render("PLAY",True,(255,255,255))
        pencere.blit(
        text,
        text.get_rect(center=oyna_butonu.center)
)

  




    if su_anki_ekran == "oyun":

        spawn_timer += 1

        if spawn_timer > 90:
            enemies.append(Enemy())
            spawn_timer = 0
        
        keys = pygame.key.get_pressed()
        road.move()
        car.move(keys)
        road.draw(pencere)
        car.draw(pencere)
        for enemy in enemies:
            enemy.move()
            enemy.draw(pencere)
            if car.get_rect().colliderect(enemy.get_rect()):
                su_anki_ekran = "game_over"
            if enemy.y > car.y and not enemy.passed:
                score += 10
                enemy.passed = True

        enemies = [enemy for enemy in enemies
                    if enemy.y < settings.HEIGHT + enemy.height]
            

        if su_anki_ekran == "game_over":
            pencere.fill((0,0,0))
            big_font=pygame.font.SysFont(None,100)
            score = 0

            boom=big_font.render(
                "BOM!",
                True,
                (255,255,255)
)
            pencere.blit(
                boom,
                boom.get_rect(center=(640,250))
                )

            pygame.draw.rect(
                pencere,
                (255,255,255),
                restart_buton,
                2
)
        text_surface = score_font.render(f"SCORE:{int(score)}", True, (255, 255, 255))
        pygame.draw.rect(pencere, (0, 0, 0), [640, 10, 150, 40], border_radius=8)
        pencere.blit(text_surface, (655, 18))          

    pygame.display.flip()  

pygame.quit()