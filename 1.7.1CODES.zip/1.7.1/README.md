# The Car 1.0

## LICENSE

This project is licensed under the **Apache License 2.0**.

## Appearance

- lobby:

- Game over:

- in game:

## How to Play

**A** or **Left Arrow**: Move left
**D** or **Right Arrow**: Move Right
**in lobby** = Click the **Play** button to start game.
**in death screen**  = Click the **Button** to restart game.

## Developer

[Developer](https://github.com/devtoprak)
