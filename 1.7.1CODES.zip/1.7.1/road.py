
import pygame
import settings

class Road:
    image = pygame.image.load("road.png")
    def __init__(self):
        self.width = settings.ROADWIDTH
        self.height = settings.ROADHEIGHT
        self.x = (settings.WIDTH - self.width) // 2

        self.image = Road.image.convert_alpha()
        self.image = pygame.transform.scale(self.image, (self.width, self.height))

        self.y1 = 0
        self.y2 = -self.height

        self.speed = 15

    def move(self):
        self.y1 += self.speed
        self.y2 += self.speed

        if self.y1 >= self.height:
            self.y1 = self.y2 - self.height

        if self.y2 >= self.height:
            self.y2 = self.y1 - self.height

    def draw(self, screen):
        screen.blit(self.image, (self.x, self.y1))
        screen.blit(self.image, (self.x, self.y2))