import settings
import pygame

road_left = 110
road_right = 1170

class Car:
    image = pygame.image.load("car.png")
    def __init__(self):
        self.width = 180
        self.height = 280
        self.x = (settings.WIDTH - self.width) // 2
        self.y = settings.HEIGHT - self.height - 100
        self.speed = 8

        self.image = Car.image.convert_alpha()
        self.image = pygame.transform.scale(self.image, (self.width, self.height))

    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)

    def draw(self, screen):
        screen.blit(self.image, (self.x, self.y))

    def move(self, keys):
        if keys[pygame.K_RIGHT] and self.x < road_right-self.width:
             self.x += self.speed

        if keys[pygame.K_d] and self.x < road_right-self.width:
             self.x += self.speed

        if keys[pygame.K_LEFT] and self.x > road_left:
            self.x -= self.speed

        if keys[pygame.K_a] and self.x > road_left:
            self.x -= self.speed
