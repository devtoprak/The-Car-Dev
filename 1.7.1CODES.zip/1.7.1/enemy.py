import pygame
import random

class Enemy:
    last_lane = None
    image = pygame.image.load("enemy.png")
    image = pygame.transform.scale(image,(180,280))

    def __init__(self):
        self.width = 180
        self.height = 280
        lanes=[320,540,760,980]
        lane = random.choice(lanes)

        while lane == Enemy.last_lane:
            lane = random.choice(lanes)

        Enemy.last_lane = lane

        self.x = lane - self.width//2
        self.y = -self.height
        self.speed = 16
        self.image = Enemy.image.convert_alpha()
        self.passed = False
    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)
         
    def move(self):
        self.y += self.speed

    def draw(self, screen):
        screen.blit(self.image, (self.x, self.y))
    
